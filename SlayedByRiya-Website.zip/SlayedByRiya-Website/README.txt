SLAYEDBYRIYA WEBSITE

Files:
- index.html — main website file
- logo.png — REQUIRED if your HTML references the logo image

Important: The current index.html references logo.png. Put the actual logo image in this same folder before uploading to GitHub if you want the logo to appear on the live site.
